# STA410 Bayes Network

Please click [here](https://github.com/BullDF/bayes_network/blob/main/documentation.pdf) for the documentation of this project.